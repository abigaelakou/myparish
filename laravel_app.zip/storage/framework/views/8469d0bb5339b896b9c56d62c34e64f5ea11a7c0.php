<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reçu de Paiement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border: 1px solid #15d387;
            border-radius: 5px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .info {
            margin-bottom: 20px;
        }

        .info label {
            font-weight: bold;
        }

        .info p {
            margin: 5px 0;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Reçu de Paiement</h1>
        
        <div class="info">
            <label>Nom et Prénom:</label>
            <p><?php echo e($recu->nom_prenom); ?></p>
        </div>

        <div class="info">
            <label>Montant:</label>
            <p><?php echo e($recu->montant); ?> FCFA</p>
        </div>

        <div class="info">
            <label>Contact:</label>
            <p><?php echo e($recu->contact); ?></p>
        </div>

        <div class="info">
            <label>Date de Paiement:</label>
            <p><?php echo e(\Carbon\Carbon::parse($recu->date_paiement)->format('d/m/Y')); ?></p>
        </div>
        <div class="footer">
            <p>Merci pour votre paiement.</p>
            <p>Veuillez envoyer ce reçu au secrétariat pour récupérer vos manuels.</p>
                <a href="<?php echo e(route('download.recu', ['id_paiement' => $recu->id])); ?>"
                class="btn btn-secondary">Télécharger le Reçu</a>

            <a href="<?php echo e(route('accueil')); ?>" class="btn btn-primary">Retour à l'accueil? </a>

        </div>
    </div>
</body>

</html><?php /**PATH C:\laragon\www\myparish\resources\views/Espaces/Catechese/recu_paiement.blade.php ENDPATH**/ ?>